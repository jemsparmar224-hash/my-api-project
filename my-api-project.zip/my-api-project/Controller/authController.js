const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("./../Models/userModel");

// REGISTER
exports.register = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        // simple validation
        if (!name || !email || !password) {
            return res.json({ success: false, message: "All fields are required" });
        }



        // pwd hash
        const hashedPassword = await bcrypt.hash(password, 10);

        const user = await User.create({
            name,
            email,
            password: hashedPassword,
        });

        return res.json({
            success: true,
            message: "User registered successfully",
            user,
        });
    } catch (err) {
        return res.json({ success: false, message: err.message });
    }
};

// LOGIN
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // simple validation
        if (!email || !password) {
            return res.json({ success: false, message: "All fields are required" });
        }

        const user = await User.findOne({ email });
        if (!user) {
            return res.json({ success: false, message: "User not found" });
        }

        // check password
        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.json({ success: false, message: "Invalid password" });
        }

        // token generate
        const token = jwt.sign({ id: user._id }, "SECRET123", {
            expiresIn: "7d",
        });

        return res.json({
            success: true,
            message: "Login successful",
            token,
            user,
        });
    } catch (err) {
        return res.json({ success: false, message: err.message });
    }
};


